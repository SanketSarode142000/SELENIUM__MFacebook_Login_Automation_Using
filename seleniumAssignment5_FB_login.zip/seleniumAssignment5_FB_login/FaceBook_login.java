package seleniumAssignment5_FB_login;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FaceBook_login {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/r.php");
		driver.manage().window().maximize();
		
		WebElement var1 = driver.findElement(By.xpath("(//input[@name='firstname'])"));                                    
		var1.sendKeys("Sanket");    //                "(//input[@id='nav-search-submit-button     '])[1]"
		
		WebElement var2 = driver.findElement(By.xpath("(//input[@class=\"inputtext _58mg _5dba _2ph-\"])[2]"));
	 	var2.sendKeys("Sarode");
	 	
	 	WebElement var3 = driver.findElement(By.xpath("(//select[@name=\"birthday_day\"])"));
//	 //	var3.click();
	 	
	 	Select dropDownDate = new Select(var3);
	 	dropDownDate.selectByValue("1");
		
		WebElement var4 = driver.findElement(By.xpath("(//select[@name=\"birthday_month\"])"));
		Select dropDownMonth = new Select(var4);
		dropDownMonth.selectByValue("4");

		
		WebElement var5 = driver.findElement(By.xpath("(//select[@class=\"_9407 _5dba _9hk6 _8esg\"])[3]"));
		Select dropDownYear = new Select(var5);
		dropDownYear.selectByValue("2000");
		
		
		List<WebElement> genderList = driver.findElements(By.xpath("(//input[@type=\"radio\"])"));
		
		int n = 0;
		for(WebElement index : genderList) {
			if(n==1) {
				index.click();
			}
			n++;
		}
		
		WebElement var6 = driver.findElement(By.xpath("(//input[@class='inputtext _58mg _5dba _2ph-'])[5]"));
		var6.sendKeys("7888054059");
		
		WebElement var7 = driver.findElement(By.xpath("(//input[@class=\"inputtext _58mg _5dba _2ph-\"])[7]"));
		var7.sendKeys("124421");
		
		WebElement var8 = driver.findElement(By.xpath("//button[@class=\"_6j mvm _6wk _6wl _58mi _3ma _6o _6v\"]"));
		var8.click();
		
	}
}
